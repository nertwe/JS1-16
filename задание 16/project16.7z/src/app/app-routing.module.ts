import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainPageComponent } from './ui/main-page/mainpage.component';

const routes: Routes = [
  {path: '', component: MainPageComponent},
  // {path: 'workers', component: },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
