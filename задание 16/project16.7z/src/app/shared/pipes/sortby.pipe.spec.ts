import { SortbyPipe } from './sortby.pipe';

describe('SortbyPipe', () => {
  it('create an instance', () => {
    const pipe = new SortbyPipe();
    expect(pipe).toBeTruthy();
  });
});
